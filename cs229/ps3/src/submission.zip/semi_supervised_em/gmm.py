import matplotlib.pyplot as plt
import numpy as np
import os

PLOT_COLORS = ['red', 'green', 'blue', 'orange']  # Colors for your plots
K = 4           # Number of Gaussians in the mixture model
NUM_TRIALS = 3  # Number of trials to run (can be adjusted for debugging)
UNLABELED = -1  # Cluster label for unlabeled data points (do not change)

def multinormal(x, mu, sigma):
    x = x.reshape(x.shape[0], 1)
    c = 1 / np.sqrt(np.linalg.det(sigma))
    exponent = (-1 / 2) * np.dot((x - mu).T, np.dot(np.linalg.inv(sigma), x - mu))
    return c * np.exp(exponent)

def get_weight_denom(x, mu, sigma, phi, n_clusters):
    w_denom = 0
    for i in range(n_clusters):
        w_denom += multinormal(x, mu[i], sigma[i]) * phi[i]
    return w_denom

def main(is_semi_supervised, trial_num):
    """Problem 3: EM for Gaussian Mixture Models (unsupervised and semi-supervised)"""
    print('Running {} EM algorithm...'
          .format('semi-supervised' if is_semi_supervised else 'unsupervised'))

    num_clusters = K
    # Load dataset
    train_path = os.path.join('.', 'train.csv')
    x_all, z_all = load_gmm_dataset(train_path)

    # Split into labeled and unlabeled examples
    labeled_idxs = (z_all != UNLABELED).squeeze()
    x_tilde = x_all[labeled_idxs, :]   # Labeled examples
    z_tilde = z_all[labeled_idxs, :]   # Corresponding labels
    x = x_all[~labeled_idxs, :]        # Unlabeled examples

    # *** START CODE HERE ***
    # (1) Initialize mu and sigma by splitting the n_examples data points uniformly at random
    # into K groups, then calculating the sample mean and covariance for each group
    mu = np.zeros((K, x.shape[1], 1))
    sigma = np.zeros((K, x.shape[1], x.shape[1]))
    index_choices = np.random.choice([i for i in range(x.shape[0])], size=num_clusters)
    index_choices.sort()
    idx_prev = 0
    for i in range(num_clusters):
        curr_batch = x[idx_prev : index_choices[i]]
        mu[i] = np.mean(curr_batch, axis=0, keepdims=True).T
        sigma[i] = 0
        for j in range(len(curr_batch)):
            sigma[i] += np.dot((curr_batch[j] - mu[i]), (curr_batch[j] - mu[i]).T)
        sigma[i] /= len(curr_batch)
        idx_prev = index_choices[i]

    # (2) Initialize phi to place equal probability on each Gaussian
    # phi should be a numpy array of shape (K,)
    phi = (1 + np.zeros((K, 1))) / K
    # (3) Initialize the w values to place equal probability on each Gaussian
    # w should be a numpy array of shape (m, K)
    w = (1 + np.zeros((x.shape[0], K))) / K
    n = w.shape[0]
    # *** END CODE HERE ***

    if is_semi_supervised:
        w = run_semi_supervised_em(x, x_tilde, z_tilde, w, phi, mu, sigma)
    else:
        w = run_em(x, w, phi, mu, sigma)

    # Plot your predictions
    z_pred = np.zeros(n)
    if w is not None:  # Just a placeholder for the starter code
        for i in range(n):
            z_pred[i] = np.argmax(w[i])

    plot_gmm_preds(x, z_pred, is_semi_supervised, plot_id=trial_num)


def run_em(x, w, phi, mu, sigma):
    """Problem 3(d): EM Algorithm (unsupervised).

    See inline comments for instructions.

    Args:
        x: Design matrix of shape (n_examples, dim).
        w: Initial weight matrix of shape (n_examples, k).
        phi: Initial mixture prior, of shape (k,).
        mu: Initial cluster means, list of k arrays of shape (dim,).
        sigma: Initial cluster covariances, list of k arrays of shape (dim, dim).

    Returns:
        Updated weight matrix of shape (n_examples, k) resulting from EM algorithm.
        More specifically, w[i, j] should contain the probability of
        example x^(i) belonging to the j-th Gaussian in the mixture.
    """
    # No need to change any of these parameters
    eps = 1e-3  # Convergence threshold
    max_iter = 1000
    n_examples, n_clusters = w.shape

    # Stop when the absolute change in log-likelihood is < eps
    # See below for explanation of the convergence criterion
    it = 0
    ll = prev_ll = None
    while it < max_iter and (prev_ll is None or np.abs(ll - prev_ll) >= eps):
        # *** START CODE HERE
        # (1) E-step: Update your estimates in w
        for i in range(n_examples):
            w_denom = get_weight_denom(x[i], mu, sigma, phi, n_clusters)
            for j in range(n_clusters):
                w[i][j] = (multinormal(x[i], mu[j], sigma[j]) * phi[j]) / w_denom
                #  if w[i][j] == 0:
                    #  print('------------------------------------------------------------------------------------------------------------------')
                    #  print(w_denom)
                    #  print('w' + str(i) + str(j) + ' ' + str(w[i][j]))
                    #  print('phi_' + str(j) + ' ' + str(phi[j]))
                    #  print('mu' + str(j) + ' ' + str(mu[j]))
                    #  print('sigma' + str(j) + ' ' + str(sigma[j]))
                    #  print('x' + str(i) + ' ' + str(x[i]))
                    #  print(multinormal(x[i], mu[j], sigma[j]))
        # (2) M-step: Update the model parameters phi, mu, and sigma
        for j in range(n_clusters):
            phi[j] = np.sum(w.T[j], axis = 0) / n_examples
            #  print(np.sum(w.T[j], axis = 0))
            #  print(np.sum(w.T[j], axis = 0).shape)
            #  print(w.T[j])
            #  print("setting mu j to be ", np.sum(np.dot(w.T[j], x)) / np.sum(w[:, j], axis = 0))
            #  mu[j] = np.sum(np.dot(w.T[j], x)) / np.sum(w[:, j], axis = 0)
            n_mu = np.zeros((x[i].shape[0], 1))
            n_mu_denom = 0
            n_sigma = np.zeros((x[i].shape[0], x[i].shape[0]))
            for i in range(n_examples):
                #  print('mu' + str(mu[j]))
                #  print('x '+str(x[i].reshape(x[i].shape[0],1)))
                #  print(x[i].reshape(x[i].shape[0],1) - mu[j])
                #  print(w[i][j].shape)
                #  print(x[i].shape)
                n_mu += w[i][j] * x[i].reshape(x[i].shape[0],1)
                n_mu_denom += w[i][j]
                n_sigma += np.dot(w[i][j], np.dot(x[i].reshape(x[i].shape[0],1) - mu[j], (x[i].reshape(x[i].shape[0],1) - mu[j]).T))
            mu[j] = n_mu / n_mu_denom
            sigma[j] = n_sigma / n_examples

        # (3) Compute the log-likelihood of the data to check for convergence.
        prev_ll = ll
        ll = 0
        for i in range(n_examples):
            logit = 0
            for j in range(n_clusters):
                logit += multinormal(x[i], mu[j], sigma[j]) * phi[j]
            ll += np.log(logit)
        if prev_ll != None:
            print(ll - prev_ll)

        # By log-likelihood, we mean `ll = sum_x[log(sum_z[p(x|z) * p(z)])]`.
        # We define convergence by the first iteration where abs(ll - prev_ll) < eps.
        # Hint: For debugging, recall part (a). We showed that ll should be monotonically increasing.
        it += 1
        print(it)
        # *** END CODE HERE ***

    return w


def run_semi_supervised_em(x, x_tilde, z_tilde, w, phi, mu, sigma):
    """Problem 3(e): Semi-Supervised EM Algorithm.

    See inline comments for instructions.

    Args:
        x: Design matrix of unlabeled examples of shape (n_examples_unobs, dim).
        x_tilde: Design matrix of labeled examples of shape (n_examples_obs, dim).
        z_tilde: Array of labels of shape (n_examples_obs, 1).
        w: Initial weight matrix of shape (n_examples, k).
        phi: Initial mixture prior, of shape (k,).
        mu: Initial cluster means, list of k arrays of shape (dim,).
        sigma: Initial cluster covariances, list of k arrays of shape (dim, dim).

    Returns:
        Updated weight matrix of shape (n_examples, k) resulting from semi-supervised EM algorithm.
        More specifically, w[i, j] should contain the probability of
        example x^(i) belonging to the j-th Gaussian in the mixture.
    """
    # No need to change any of these parameters
    alpha = 20.  # Weight for the labeled examples
    eps = 1e-3   # Convergence threshold
    max_iter = 1000
    n = x.shape[0]
    n_tilde = x_tilde.shape[0]
    n_examples, n_clusters = w.shape
    n_examples_obs = n_examples - n

    # Stop when the absolute change in log-likelihood is < eps
    # See below for explanation of the convergence criterion
    it = 0
    ll = prev_ll = None
    while it < max_iter and (prev_ll is None or np.abs(ll - prev_ll) >= eps):
        # *** START CODE HERE ***
        # (1) E-step: Update your estimates in w
        for i in range(n_examples):
            w_denom = get_weight_denom(x[i], mu, sigma, phi, n_clusters)
            for j in range(n_clusters):
                w[i][j] = (multinormal(x[i], mu[j], sigma[j]) * phi[j]) / w_denom
        # (2) M-step: Update the model parameters phi, mu, and sigma
        for j in range(n_clusters):
            phi[j] = (1 / n + alpha * n_tilde) * (np.sum(w.T[j], axis = 0) + np.sum(z_tilde == j))
            #  mu[j] = (np.sum(np.dot(w.T[j], x)) + alpha * np.sum(np.dot(z_tilde == j, x))) / (np.sum(w.T[j], axis = 0) + np.sum(z_tilde == j))
            n_mu = np.zeros((x[i].shape[0], 1))
            n_mu_denom = 0
            s_numerator = 0
            s_denominator = 0
            # unobserved part
            for i in range(n):
                n_mu += w[i][j] * x[i].reshape(x[i].shape[0],1)
                n_mu_denom += w[i][j]
                s_numerator += np.dot(w[i][j], np.dot(x[i].reshape(x[i].shape[0],1) - mu[j], (x[i].reshape(x[i].shape[0],1) - mu[j]).T))
                s_denominator += (np.sum(w.T[j], axis = 0))
            # observed part
            for i in range(n_examples_obs):
                n_mu += alpha * (z_tilde[i] == j) * x_tilde[i]
                s_numerator += alpha * np.dot(z_tilde == j, np.dot(x_tilde[i].reshape(x_tilde[i].shape[0],1) - mu[j], (x_tilde[i].reshape(x_tilde[i].shape[0],1) - mu[j]).T))
                s_denominator += np.sum(z_tilde == j, axis = 0)
            mu[j] = (n_mu)/(n_mu_denom + np.sum(z_tilde == j))
            sigma[j] = s_numerator / s_denominator
        # (3) Compute the log-likelihood of the data to check for convergence.
        prev_ll = ll
        ll = 0
        # unobserved part
        for i in range(n):
            logit = 0
            for j in range(n_clusters):
                logit += multinormal(x[i], mu[j], sigma[j]) * phi[j]
            ll += np.log(logit)
        # observed part
        for i in range(n_examples_obs):
            logit = multinormal(x_tilde[i], mu[z_tilde[i]], sigma[z_tilde[i]]) * phi[z_tilde[i]]
            ll += alpha * np.log(logit)
        it += 1
        # Hint: Make sure to include alpha in your calculation of ll.
        # Hint: For debugging, recall part (a). We showed that ll should be monotonically increasing.
        # *** END CODE HERE ***
    return w


# *** START CODE HERE ***
# Helper functions
# *** END CODE HERE ***


def plot_gmm_preds(x, z, with_supervision, plot_id):
    """Plot GMM predictions on a 2D dataset `x` with labels `z`.

    Write to the output directory, including `plot_id`
    in the name, and appending 'ss' if the GMM had supervision.

    NOTE: You do not need to edit this function.
    """
    plt.figure(figsize=(12, 8))
    plt.title('{} GMM Predictions'.format('Semi-supervised' if with_supervision else 'Unsupervised'))
    plt.xlabel('x_1')
    plt.ylabel('x_2')

    for x_1, x_2, z_ in zip(x[:, 0], x[:, 1], z):
        color = 'gray' if z_ < 0 else PLOT_COLORS[int(z_)]
        alpha = 0.25 if z_ < 0 else 0.75
        plt.scatter(x_1, x_2, marker='.', c=color, alpha=alpha)

    file_name = 'pred{}_{}.pdf'.format('_ss' if with_supervision else '', plot_id)
    save_path = os.path.join('.', file_name)
    plt.savefig(save_path)


def load_gmm_dataset(csv_path):
    """Load dataset for Gaussian Mixture Model.

    Args:
         csv_path: Path to CSV file containing dataset.

    Returns:
        x: NumPy array shape (n_examples, dim)
        z: NumPy array shape (n_exampls, 1)

    NOTE: You do not need to edit this function.
    """

    # Load headers
    with open(csv_path, 'r') as csv_fh:
        headers = csv_fh.readline().strip().split(',')

    # Load features and labels
    x_cols = [i for i in range(len(headers)) if headers[i].startswith('x')]
    z_cols = [i for i in range(len(headers)) if headers[i] == 'z']

    x = np.loadtxt(csv_path, delimiter=',', skiprows=1, usecols=x_cols, dtype=float)
    z = np.loadtxt(csv_path, delimiter=',', skiprows=1, usecols=z_cols, dtype=float)

    if z.ndim == 1:
        z = np.expand_dims(z, axis=-1)

    return x, z


if __name__ == '__main__':
    np.random.seed(229)
    # Run NUM_TRIALS trials to see how different initializations
    # affect the final predictions with and without supervision
    for t in range(NUM_TRIALS):
        main(is_semi_supervised=True, trial_num=t)

        # *** START CODE HERE ***
        # Once you've implemented the semi-supervised version,
        # uncomment the following line.
        # You do not need to add any other lines in this code block.
        # main(is_semi_supervised=True, trial_num=t)
        # *** END CODE HERE ***
